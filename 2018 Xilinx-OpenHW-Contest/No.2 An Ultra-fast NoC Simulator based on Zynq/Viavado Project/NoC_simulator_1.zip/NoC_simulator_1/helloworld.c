/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
//#include "xil_printf.h"
#include "xil_io.h"
#include "AXI_addr.h"
#include "AXI_collect.h"
#include "AXI_ctrl.h"
#include "xparameters.h"





int main()
{

	int collect_L_0,collect_H_0,collect_L_1,collect_H_1,collect_L_2,collect_H_2,collect_L_3,collect_H_3,collect_L_4,collect_H_4;
	int i,j;

	init_platform();
//	xil_printf("hello1");

	while(1)
	{


		xil_printf("hello2");
		//ADDR
		AXI_ADDR_mWriteReg(XPAR_AXI_ADDR_0_S00_AXI_BASEADDR,AXI_ADDR_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_ADDR_mWriteReg(XPAR_AXI_ADDR_1_S00_AXI_BASEADDR,AXI_ADDR_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_ADDR_mWriteReg(XPAR_AXI_ADDR_2_S00_AXI_BASEADDR,AXI_ADDR_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_ADDR_mWriteReg(XPAR_AXI_ADDR_3_S00_AXI_BASEADDR,AXI_ADDR_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_ADDR_mWriteReg(XPAR_AXI_ADDR_4_S00_AXI_BASEADDR,AXI_ADDR_S00_AXI_SLV_REG0_OFFSET,0x001);
		xil_printf("ADDR =  %d \n\r",AXI_ADDR_mReadReg(XPAR_AXI_ADDR_0_S00_AXI_BASEADDR,AXI_ADDR_S00_AXI_SLV_REG0_OFFSET));

		//Clk_ctrl
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_1_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_2_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_3_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG0_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_4_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG0_OFFSET,0x001);
		xil_printf("Clk_ctrl =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG0_OFFSET));

		//Traffic_type
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG1_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_1_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG1_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_2_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG1_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_3_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG1_OFFSET,0x001);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_4_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG1_OFFSET,0x001);
		xil_printf("Traffic_type =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG1_OFFSET));
		//Packet_num_in
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET,0x004);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_1_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET,0x005);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_2_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET,0x006);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_3_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET,0x007);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_4_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET,0x008);
		xil_printf("Packet_num_in_router_0 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET));
		xil_printf("Packet_num_in_router_1 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_1_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET));
		xil_printf("Packet_num_in_router_2 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_2_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET));
		xil_printf("Packet_num_in_router_3 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_3_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET));
		xil_printf("Packet_num_in_router_4 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_4_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG2_OFFSET));
		//Flit_num_in
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET,0x004);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_1_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET,0x005);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_2_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET,0x006);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_3_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET,0x007);
		AXI_CTRL_mWriteReg(XPAR_AXI_CTRL_4_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET,0x008);
		xil_printf("Flit_num_in_router_0 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_0_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET));
		xil_printf("Flit_num_in_router_0 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_1_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET));
		xil_printf("Flit_num_in_router_0 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_2_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET));
		xil_printf("Flit_num_in_router_0 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_3_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET));
		xil_printf("Flit_num_in_router_0 =  %d \n\r",AXI_CTRL_mReadReg(XPAR_AXI_CTRL_4_S00_AXI_BASEADDR,AXI_CTRL_S00_AXI_SLV_REG3_OFFSET));


		//Data_num_in[9:0]
		AXI_BRAM_64BIT_mWriteReg(XPAR_AXI_BRAM_64BIT_1_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG0_OFFSET,0x005);
		xil_printf("Data_num_in[9:0]: %d \n\r",AXI_BRAM_64BIT_mReadReg(XPAR_AXI_BRAM_64BIT_1_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG0_OFFSET));

		//Packet_num_in[9:0]
		AXI_BRAM_64BIT_mWriteReg(XPAR_AXI_BRAM_64BIT_2_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG0_OFFSET,0x005);
		xil_printf("Packet_num_in[9:0]: %d \n\r",AXI_BRAM_64BIT_mReadReg(XPAR_AXI_BRAM_64BIT_2_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG0_OFFSET));

		//data_rec_mem_addr[9:0] -> data_rec_mem_data[63:0]
		AXI_BRAM_64BIT_mWriteReg(XPAR_AXI_BRAM_64BIT_3_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG0_OFFSET,0x000);
		rdata1=AXI_BRAM_64BIT_mReadReg(XPAR_AXI_BRAM_64BIT_3_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG1_OFFSET);
		rdata2=AXI_BRAM_64BIT_mReadReg(XPAR_AXI_BRAM_64BIT_3_S_AXI_BASEADDR,AXI_BRAM_64BIT_S_AXI_SLV_REG2_OFFSET);
		xil_printf("data_rec_mem_data[63:0]_0x000: %d %d \n\r",rdata1,rdata2);

		//Collect data
		collect_L_0=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG2_OFFSET);
		collect_H_0=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG3_OFFSET);
		xil_printf("Router0 collection: %d %d \n\r",collect_H_0,collect_L_0);

		collect_L_1=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG2_OFFSET);
		collect_H_1=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG3_OFFSET);
		xil_printf("Router1 collection: %d %d \n\r",collect_H_1,collect_L_1);

		collect_L_2=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG2_OFFSET);
		collect_H_2=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG3_OFFSET);
		xil_printf("Router2 collection: %d %d \n\r",collect_H_2,collect_L_2);

		collect_L_3=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG2_OFFSET);
		collect_H_3=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG3_OFFSET);
		xil_printf("Router3 collection: %d %d \n\r",collect_H_3,collect_L_3);

		collect_L_4=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG2_OFFSET);
		collect_H_4=AXI_COLLECT_mReadReg(XPAR_AXI_COLLECT_0_S00_AXI_BASEADDR,AXI_COLLECT_S00_AXI_SLV_REG3_OFFSET);
		xil_printf("Router4 collection: %d %d \n\r",collect_H_4,collect_L_4);



		for(i=0;i<10000;i++)
		{
			for(j=0;j<10000;j++);
		}


		xil_printf("router1 50 3 20 30 12 ");
		xil_printf("router2 50 3 21 31 14 ");
		xil_printf("router3 50 3 22 32 13 ");
		xil_printf("router4 40 3 20 30 12 ");



		for(i=0;i<10000;i++)
	    {
		    for(j=0;j<10000;j++);
		}

	    xil_printf("router1 50 3 26 35 12 ");
		xil_printf("router2 50 3 27 37 14 ");
		xil_printf("router3 50 3 25 36 13 ");
		xil_printf("router4 40 3 28 38 12 ");

	}



	cleanup_platform();

	return 0;
}
